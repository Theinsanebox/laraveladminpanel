@include('css')
@include('sidebar')
<script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
   
   gtag('config', 'UA-120946860-7');
   
</script>
<style>
	.padding-modal{
		padding: 0px 30px!important;
	}
	.our-btn{
		background: #153D77!important;
		color: white!important;
		border: none!important;
		border-radius: 8px!important;
		padding: 7px 11px!important;
		width: fit-content!important;
	}
	.w-5{
		display: none;
	}

</style>
</head>
<body>
   <div class="wrapper">
      <div class="main">
         <x-header />
         <main class="content">
            <div class="container-fluid">
                <div class="card-body">
                    <div class="clearfix">
                        {{-- <div style="font-size:1cm;text-transform:uppercase;" id="quill-editor" class="ql-container ql-snow"><div class="ql-editor ql-blank" data-gramm="false" contenteditable="true"><p><br></p></div><div class="ql-clipboard" contenteditable="true" tabindex="-1"></div><div class="ql-tooltip ql-hidden"><a class="ql-preview" rel="noopener noreferrer" target="_blank" href="about:blank"></a><input type="text" value="1" data-formula="e=mc^2" data-link="https://quilljs.com" data-video="Embed URL"><a class="ql-action"></a><a class="ql-remove"></a></div></div> --}}
                        <form action="dboperation" method="get">
                            <textarea name="editorx" style="background:#EDEDED;height:70vh;width:90vw;color:black;position:relative;top:10px;font-size:1cm;text-transform:uppercase;" ></textarea>
                            <input type="submit" class="our-btn" style="position:relative;top:20px;" name="sbmt">
                        </form>
                    </div>
                </div>
            </div>
         </main>
      </div>
   </div>

	
</body>
</html>

<script>
	function findusers(){

	}
</script>