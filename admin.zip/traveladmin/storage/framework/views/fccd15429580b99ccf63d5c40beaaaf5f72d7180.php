<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
   
   gtag('config', 'UA-120946860-7');
   
</script>
<style>
	.padding-modal{
		padding: 0px 30px!important;
	}
	.our-btn{
		background: #153D77!important;
		color: white!important;
		border: none!important;
		border-radius: 8px!important;
		padding: 7px 11px!important;
		width: fit-content!important;
	}
	.w-5{
		display: none;
	}

</style>
</head>
<body>
   <div class="wrapper">
      <div class="main">
         <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
         <main class="content">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-12">
                     <div class="card">
                        <div class="card-header">
                           <h5 class="card-title">User Information</h5>
						   <button type="button" class="btn btn-success our-btn" data-bs-toggle="modal" data-bs-target="#staticBackdropUser">Add New User</button>
<span style="float: right;">
	<form action="findusers" method="GET">
		<input type="text" onkeypress="findusers()" style="float: right;padding-left:10px;" name="searchbar" placeholder="Search User By Name">
	</form>
</span>
                        </div>
                        <div class="card-body">
                           <table id="datatables-basic" class="table table-striped" style="width:100%">
                              <tr>
                                 <td>Name</td>
                                 <td>AgencyName</td>
                                 <td>Login ID</td>
                                 <td>Email</td>
                                 
                                 <td>Mobile</td>
                                 <td>Phone</td>
                                 <td>GST NO</td>
                                 <td>PAN NO</td>
                                 <td>City</td>
                                 
                                 
                                 
                                 <td>Status</td>
                                 <td>Operation</td>
                              </tr>
                              <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td><?php echo e($i['name']); ?></td>
                                 <td><?php echo e($i['agencyname']); ?></td>
                                 <td><?php echo e($i['loginid']); ?></td>
                                 <td><?php echo e($i['email']); ?></td>
                                 
                                 <td><?php echo e($i['mobile']); ?></td>
                                 <td><?php echo e($i['phone']); ?></td>
                                 <td><?php echo e($i['gstno']); ?></td>
                                 <td><?php echo e($i['panno']); ?></td>
                                 <td><?php echo e($i['city']); ?></td>
                                 
                                 
                                 
                                 <td><?php echo e($i['status']); ?></td>
                                 <td>
									<button type="button" class="btn btn-success our-btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo e($i['id']); ?>"><i class="fas fa-edit"></i></button>
									<button type="button" class="btn btn-primary our-btn" data-toggle="modal" data-target="#exampleModal2<?php echo e($i['id']); ?>"> <i class="fas fa-lock"></i> </button>
									<button type="button" class="btn btn-primary our-btn" data-toggle="modal" data-target="#exampleModal<?php echo e($i['id']); ?>"> <i class="fas fa-trash-alt"></i> </button>
                                 </td>
								 
						<form action="delete/<?php echo e($i['id']); ?>">
								 <div class="modal fade" id="exampleModal<?php echo e($i['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
									<div class="modal-dialog" role="document">
									  <div class="modal-content">
										<div class="modal-header">
										  <h5 class="modal-title" id="exampleModalLabel">Delete Record</h5>
										  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										  </button>
										</div>
										<div class="modal-body">
										  Are you sure that you wanna delete this record?
										</div>
										<div class="modal-footer">
										  <button type="button" class="our-btn" data-dismiss="modal">No</button>
										  <input type="submit" class="our-btn" value="Yes">
										</div>
									  </div>
									</div>
								  </div>
							</form>
								

								
						<form action="lock/<?php echo e($i['id']); ?>">
							<div class="modal fade" id="exampleModal2<?php echo e($i['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							   <div class="modal-dialog" role="document">
								 <div class="modal-content">
								   <div class="modal-header">
									 <h5 class="modal-title" id="exampleModalLabel">Record Activation</h5>
									 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									   <span aria-hidden="true">&times;</span>
									 </button>
								   </div>
								   <div class="modal-body">
									 Are you sure that you wanna Change this record's status?
								   </div>
								   <div class="modal-footer">
									 <button type="button" class="our-btn" data-dismiss="modal">No</button>
									 <input type="submit" class="our-btn" value="Yes">
								   </div>
								 </div>
							   </div>
							 </div>
					   </form>
						   

								 
								 <div class="modal fade bs-example-modal-lg" id="staticBackdrop<?php echo e($i['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title mt-0" id="staticBackdropLabel">Edit Information </h5>
											</div>
											<form action="update/<?php echo e($i['id']); ?>" class="form" id="add_model" enctype="multipart/form-data" role="form" method="post" >
												<?php echo csrf_field(); ?>
											<div class="modal-body">
												<div class="row">
													<div class="modal-body">
														<div class="form-group">
															<label>Name</label>
															<input required class="form-control form-control-lg" type="text" name="name" placeholder="Enter your name" value="<?php echo e($i['name']); ?>" />
														</div>
														<div class="form-group">
															<label>Agency Name</label>
															<input required class="form-control form-control-lg" type="text" name="agencyname" placeholder="Enter your Agency name" value="<?php echo e($i['agencyname']); ?>" />
														</div>
														<div class="form-group">
															<label>Login ID</label>
															<input required class="form-control form-control-lg" type="text" name="loginid" placeholder="Enter your Login ID" value="<?php echo e($i['loginid']); ?>" />
														</div>
														<div class="form-group">
															<label>Email</label>
															<input required class="form-control form-control-lg" type="email" name="email" placeholder="Enter your Email" value="<?php echo e($i['email']); ?>" />
														</div>
														<div class="form-group">
															<label>Alternate Email</label>
															<input required class="form-control form-control-lg" type="email" name="alternateemail" placeholder="Enter your Alternate Email" value="<?php echo e($i['alternateemail']); ?>" />
														</div>
														<div class="form-group">
															<label>Mobile</label>
															<input required class="form-control form-control-lg" type="number" name="mobile" placeholder="Enter your Mobile Number" value="<?php echo e($i['mobile']); ?>" />
														</div>
														<div class="form-group">
															<label>Phone</label>
															<input required class="form-control form-control-lg" type="number" name="phone" placeholder="Enter Phone Number" value="<?php echo e($i['phone']); ?>" />
														</div>
														<div class="form-group">
															<label>GST NO</label>
															<input required class="form-control form-control-lg" type="text" name="gstno" placeholder="Enter your GST NO" value="<?php echo e($i['gstno']); ?>" />
														</div>
														<div class="form-group">
															<label>PAN NO</label>
															<input required class="form-control form-control-lg" type="text" name="panno" placeholder="Enter your PAN NO" value="<?php echo e($i['panno']); ?>" />
														</div>
														<div class="form-group">
															<label>City</label>
															<input required class="form-control form-control-lg" type="text" name="city" placeholder="Enter your City" value="<?php echo e($i['city']); ?>" />
														</div>
														<div class="form-group">
															<label>State</label>
															<input required class="form-control form-control-lg" type="text" name="state" placeholder="Enter your State" value="<?php echo e($i['state']); ?>" />
														</div>
														<div class="form-group">
															<label>Pin Code</label>
															<input required class="form-control form-control-lg" type="number" name="pincode" placeholder="Enter your Pincode" value="<?php echo e($i['pincode']); ?>" />
														</div>
														<div class="form-group">
															<label>Referred By</label>
															<input required class="form-control form-control-lg" type="text" name="referredby" placeholder="Enter your Referal Code" readonly value="<?php echo e($i['referredby']); ?>" />
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<!-- <button type="button" class="btn btn-default m-l-5 pull-left" data-dismiss="modal">Cancel</button> -->
												 <button type="button" class="btn btn-secondary " data-bs-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary m-r-5 our-btn">Submit</button>
												<input type="hidden" name="mode" value="add">
											</div>
											</form>
										</div>
									</div>
								</div>
								
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
      </div>
   </div>

	 
	 <div class="modal fade bs-example-modal-lg" id="staticBackdropUser" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title mt-0" id="staticBackdropLabel">Add New User </h5>
				</div>
				<form action="insert" class="form" id="add_model" enctype="multipart/form-data" role="form" method="post" >
					<?php echo csrf_field(); ?>
				<div class="modal-body">
					<div class="form-group">
						<label>Name</label>
						<input required class="form-control form-control-lg" type="text" name="name" placeholder="Enter your name" />
					</div>
					<div class="form-group">
						<label>Agency Name</label>
						<input required class="form-control form-control-lg" type="text" name="agencyname" placeholder="Enter your Agency name" />
					</div>
					<div class="form-group">
						<label>Login ID</label>
						<input required class="form-control form-control-lg" type="text" name="loginid" placeholder="Enter your Login ID" />
					</div>
					<div class="form-group">
						<label>Email</label>
						<input required class="form-control form-control-lg" type="email" name="email" placeholder="Enter your Email" />
					</div>
					<div class="form-group">
						<label>Alternate Email</label>
						<input required class="form-control form-control-lg" type="email" name="alternateemail" placeholder="Enter your Alternate Email" />
					</div>
					<div class="form-group">
						<label>Mobile</label>
						<input required class="form-control form-control-lg" type="number" name="mobile" placeholder="Enter your Mobile Number" />
					</div>
					<div class="form-group">
						<label>Phone</label>
						<input required class="form-control form-control-lg" type="number" name="phone" placeholder="Enter Phone Number" />
					</div>
					<div class="form-group">
						<label>GST NO</label>
						<input required class="form-control form-control-lg" type="text" name="gstno" placeholder="Enter your GST NO" />
					</div>
					<div class="form-group">
						<label>PAN NO</label>
						<input required class="form-control form-control-lg" type="text" name="panno" placeholder="Enter your PAN NO" />
					</div>
					<div class="form-group">
						<label>City</label>
						<input required class="form-control form-control-lg" type="text" name="city" placeholder="Enter your City" />
					</div>
					<div class="form-group">
						<label>State</label>
						<input required class="form-control form-control-lg" type="text" name="state" placeholder="Enter your State" />
					</div>
					<div class="form-group">
						<label>Pin Code</label>
						<input required class="form-control form-control-lg" type="number" name="pincode" placeholder="Enter your Pincode" />
					</div>
					<div class="form-group">
						<label>Referred By</label>
						<input required class="form-control form-control-lg" type="text" name="referredby" placeholder="Enter your Referal Code" />
					</div>
				</div>
				<div class="modal-footer">
					<!-- <button type="button" class="btn btn-default m-l-5 pull-left" data-dismiss="modal">Cancel</button> -->
					 <button type="button" class="btn btn-secondary " data-bs-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary m-r-5 our-btn">Submit</button>
					<input type="hidden" name="mode" value="add">
				</div>
				</form>
			</div>
		</div>
	</div>
	



   <svg width="0" height="0" style="position:absolute">
      <defs>
         <symbol viewBox="0 0 512 512" id="ion-ios-pulse-strong">
            <path
               d="M448 273.001c-21.27 0-39.296 13.999-45.596 32.999h-38.857l-28.361-85.417a15.999 15.999 0 0 0-15.183-10.956c-.112 0-.224 0-.335.004a15.997 15.997 0 0 0-15.049 11.588l-44.484 155.262-52.353-314.108C206.535 54.893 200.333 48 192 48s-13.693 5.776-15.525 13.135L115.496 306H16v31.999h112c7.348 0 13.75-5.003 15.525-12.134l45.368-182.177 51.324 307.94c1.229 7.377 7.397 11.92 14.864 12.344.308.018.614.028.919.028 7.097 0 13.406-3.701 15.381-10.594l49.744-173.617 15.689 47.252A16.001 16.001 0 0 0 352 337.999h51.108C409.973 355.999 427.477 369 448 369c26.511 0 48-22.492 48-49 0-26.509-21.489-46.999-48-46.999z">
            </path>
         </symbol>
      </defs>
   </svg>
</body>
</html>

<script>
	function findusers(){

	}
</script><?php /**PATH C:\xampp\htdocs\traveladmin\resources\views/users.blade.php ENDPATH**/ ?>