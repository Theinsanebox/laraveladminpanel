
<nav id="sidebar" class="sidebar" style="box-shadow:0px 3px 10px 4px #bbbaba;position:fixed!important;left:0px!important;top:0px!important;height:100vh!important;">
    <a class="sidebar-brand" style="color: white">
            Control Panel <button onClick="closeSidebar()" style="position:relative!important;left:65px!important;border:none;background:transparent;color:white;">&#10006;</button>
    </a>
    <div class="sidebar-content">
      <div class="sidebar-user">
        <img src="https://jainilsoni1706.github.io/jass/j240.png" class="img-fluid rounded-circle mb-2" alt="Linda Miller"/>
        <div class="font-weight-bold"><?php echo e(session('email')); ?></div>
        <small>Admin</small>
      </div>
      <ul class="sidebar-nav">
        <li class="sidebar-header">
           Main
        </li>
        <li class="sidebar-item"><a class="sidebar-link" href="home">Dashboard</a></li>
        <li class="sidebar-item"><a class="sidebar-link" href="users">Users</a></li>
        <li class="sidebar-item"><a class="sidebar-link" href="admin">Admin</a></li>
        <li class="sidebar-item"><a class="sidebar-link" href="dboperation">Database Operation</a></li>
      </ul>
    </div>
  </nav>

  <script>
    let sidebarx = document.querySelector('.sidebar');
    function closeSidebar(){
      sidebarx.style.display = 'none'; 
    }
  </script><?php /**PATH C:\xampp\htdocs\traveladmin\resources\views/sidebar.blade.php ENDPATH**/ ?>