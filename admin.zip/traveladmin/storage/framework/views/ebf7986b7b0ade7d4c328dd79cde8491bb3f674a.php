<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
   
   gtag('config', 'UA-120946860-7');
   
</script>
<style>
	.padding-modal{
		padding: 0px 30px!important;
	}
	.our-btn{
		background: #153D77!important;
		color: white!important;
		border: none!important;
		border-radius: 8px!important;
		padding: 7px 11px!important;
		width: fit-content!important;
	}
	.w-5{
		display: none;
	}

</style>
</head>
<body>
   <div class="wrapper">
      <div class="main">
         <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
         <main class="content">
            <div class="container-fluid">
                <div class="card-body">
                    <div class="clearfix">
                        
                        <form action="dboperation" method="get">
                            <textarea name="editorx" style="background:#EDEDED;height:70vh;width:90vw;color:black;position:relative;top:10px;font-size:1cm;text-transform:uppercase;" ></textarea>
                            <input type="submit" class="our-btn" style="position:relative;top:20px;" name="sbmt">
                        </form>
                    </div>
                </div>
            </div>
         </main>
      </div>
   </div>

	
</body>
</html>

<script>
	function findusers(){

	}
</script><?php /**PATH C:\xampp\htdocs\traveladmin\resources\views/dbeditor.blade.php ENDPATH**/ ?>