<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usertable;
use App\Models\adminuser;
use App\Models\superadmin;
use Illuminate\Support\Facades\DB;



class alluser extends Controller
{
    function insertData(Request $req){

        $usertable = new usertable;
        $usertable->name = $req->name;
        $usertable->agencyname = $req->agencyname;
        $usertable->loginid = $req->loginid;
        $usertable->email = $req->email;
        $usertable->alternateemail = $req->alternateemail;
        $usertable->mobile = $req->mobile;
        $usertable->phone = $req->phone;
        $usertable->gstno = $req->gstno;
        $usertable->panno = $req->panno;
        $usertable->city = $req->city;
        $usertable->state = $req->state;
        $usertable->pincode = $req->pincode;
        $usertable->referredby = $req->referredby;
        $usertable->save();

        return redirect('users');
    }

    function showData(){

        $data = usertable::all();
        return view('users',['allData'=>$data]);
    }

    function updateData(Request $id){

        $usertable = new usertable;
        $usertable = usertable::find($id->id);
        $usertable->name = $id->name;
        $usertable->agencyname = $id->agencyname;
        $usertable->loginid = $id->loginid;
        $usertable->email = $id->email;
        $usertable->alternateemail = $id->alternateemail;
        $usertable->mobile = $id->mobile;
        $usertable->phone = $id->phone;
        $usertable->gstno = $id->gstno;
        $usertable->panno = $id->panno;
        $usertable->city = $id->city;
        $usertable->state = $id->state;
        $usertable->pincode = $id->pincode;
        $usertable->referredby = $id->referredby;
        $usertable->save();

        return redirect('users');
    }

    function deleteData(Request $id){

        $usertable = new usertable;
        $usertable = usertable::find($id->id);
        $usertable->delete();

        return redirect('users');
    }

    //For lock user (activataion/deactivation)
    function lockData(Request $id){

        $usertable = new usertable;
        $usertable = usertable::find($id->id);
        $one = 1;
        $zero = 0;

       
            if($id->status == $id->$one){
                $usertable->status = $zero;
            }
            else{
                $usertable->status = $one;
            }    

        $usertable->save();
        return redirect('users');
    }

    //For Login (Admin Aand Super Admin)
    function CheckLogin(Request $req){

        $data = $req->input();
        $req->session()->put('email',$data['email']);
        $req->session()->put('password',$data['password']);


        $admintable = DB::select("SELECT * FROM superadmin WHERE email='".$req->email."'");
        $admintable2 = DB::select("SELECT * FROM superadmin WHERE password='".$req->password."'");
        $admintable3 = DB::select("SELECT * FROM adminusers WHERE email='".$req->email."'");
        $admintable4 = DB::select("SELECT * FROM adminusers WHERE password='".$req->password."'");

        if($admintable && $admintable2 || $admintable3 && $admintable4){
            return redirect('home');
        }
        else{
            return redirect('');
        }

        
    }
      
    function logout(){
        if(session()->has('email') && session()->has('password')){
            session()->pull('email');
            session()->pull('password');
        }
       
        return redirect('');
    }

      function countation(){
        $x = DB::table('usertables')->count("name");
        $y = DB::table('adminusers')->count("email");
        return view('dashboard',['theData'=>$x,'theData2'=>$y]);
    }
    

    //For API
    function newFun(){
        return usertable::all();
    }

    function newFun2(Request $id){
        return usertable::find($id->id);
    }

    function newFun3(Request $req){
        
        $adminuser = new adminuser;
        $adminuser->email = $req->email;
        $adminuser->password = $req->password;
        $res = $adminuser->save();

        if($res){
            return "Data has been saved successfully.";
        }
        else{
            return "Some error occured while saving the data.";
        }
    }

//For Admin User
    function adminShow(){

        $x = adminuser::all();

        return view('admin',['allData'=>$x]);
    }
   
    function adminAdd(Request $req){
        $add = new adminuser;
        $add->email = $req->email;
        $add->password = $req->password;
        $add->save();

        return redirect('admin');

    }

    function adminUpdate(Request $req){

        $add = new adminuser;
        $add = adminuser::find($req->id);
        $add->email = $req->email;
        $add->password = $req->password;
        $add->save();

        return redirect('admin');


    }

    function adminDelete(Request $id){

        $dataDelete = adminuser::find($id->id);
        $dataDelete->delete();

        return redirect('admin');
    }

//Dbeditor

    function dboperation1(Request $req){

        if(isset($req->sbmt)){
            DB::select($req->editorx);
        }
        return view('dbeditor');
    }


}

