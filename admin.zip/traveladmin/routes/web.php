<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\alluser;



Route::view('users','users');
Route::view('register','register');
Route::view('/','login');



Route::post('insert',[alluser::class,'insertData']);
Route::get('users',[alluser::class,'showData']);
Route::get('delete/{id}',[alluser::class,'deleteData']);
Route::post('update/{id}',[alluser::class,'updateData']);
Route::get('lock/{id}',[alluser::class,'lockData']);

Route::post('checklogin',[alluser::class,'CheckLogin']);
Route::get('logout',[alluser::class,'logout']);


Route::get('home',[alluser::class,'countation']);


//admins

Route::post('adminAdd',[alluser::class,'adminAdd']);
Route::get('admin',[alluser::class,'adminShow']);
Route::post('adminu/{id}',[alluser::class,'adminUpdate']);
Route::get('admind/{id}',[alluser::class,'adminDelete']);

//dboperation

Route::get('dboperation',[alluser::class,'dboperation1']);