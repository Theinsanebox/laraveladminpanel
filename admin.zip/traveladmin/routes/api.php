<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\alluser;


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('userAPI',[alluser::class,'newFun']);
Route::get('userAPI/{id}',[alluser::class,'newFun2']);

Route::post('userAPI2',[alluser::class,'newFun3']);